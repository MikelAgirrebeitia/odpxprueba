from odpxprueba import odpxprueba
from odpxprueba2 import plot_outliers, outliers